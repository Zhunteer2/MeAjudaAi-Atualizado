const estado = document.querySelector("#estado")
const cidade = document.querySelector("#cidade")

const pegarEstado = async () => {

    const link = `https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome`

    const data = await fetch(link)
        .then(response => response.json()).catch(error => false)

    if(!data) return

    inserirEstado(data)

}

const inserirEstado = (data) => {

    estado.innerHTML = `<option value="">SELECIONE</option>`

    data.forEach(linha => {

        const { sigla, nome } = linha

        estado.innerHTML += `<option value="${sigla}">${nome}</option>`

    })

    estado.addEventListener("change", e => pegarCidade(estado.value))

}

const pegarCidade = async (uf) => {

    cidade.innerHTML = `<option value="">SELECIONE</option>`
    
    const link = `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios`

    const data = await fetch(link)
        .then(response => response.json()).catch(error => false)

    if(!data) return

    inserirCidade(data)

}

const inserirCidade = (data) => {

    data.forEach(linha => {

        const { nome } = linha

        cidade.innerHTML += `<option value="${nome}">${nome}</option>`

    })

}

pegarEstado()