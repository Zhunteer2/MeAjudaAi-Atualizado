const searchInput = document.getElementById('input_busca');
const list = document.getElementById('list');
const items = list.getElementsByTagName('li');

searchInput.addEventListener('focus', function() {
  list.style.display = 'block';
});

searchInput.addEventListener('keyup', function(event) {
  const searchText = event.target.value.toLowerCase();

  Array.from(items).forEach(function(item) {
    const text = item.textContent.toLowerCase();
    if (text.includes(searchText)) {
      const index = text.indexOf(searchText);
      const matchedText = item.textContent.substring(index, index + searchText.length);
      const highlightedText = item.textContent.replace(matchedText, `<strong>${matchedText}</strong>`);
      
      item.innerHTML = highlightedText;
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
});

document.addEventListener('click', function(event) {
  if (event.target !== searchInput) {
    list.style.display = 'none';
  }
});