<?php

  if(isset($_POST['submit'])) 
    { 
      /*
      print_r($_POST['nome']); 
      print_r('<br>');

      print_r($_POST['email']);
      print_r('<br>');

      print_r($_POST['telefone']);
      print_r('<br>');
      
      print_r($_POST['celular']);
      print_r('<br>');
      
      print_r($_POST['data_nasc']);
      print_r('<br>');

      print_r($_POST['cpf']);
      print_r('<br>');

      print_r($_POST['especialidade']);
      print_r('<br>');  
      
      print_r($_POST['estado']);
      echo '-';
      */

        include_once("config.php");
    
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $telefone = $_POST["telefone"];
        $celular = $_POST["celular"];
        $data_nasc = $_POST["data_nasc"];
        $cpf = $_POST["cpf"];
        $especialidade = $_POST["especialidade"];
        $estado = $_POST["estado"];
        $cidade = $_POST["cidade"];
        $tipo = 1;
        
                /*
               try {
        $result= mysqli_query($conexao, "INSERT INTO tecnico(nome, email, senha, telefone, celular, data_nasc, cpf, especialidade, estado, cidade) VALUES ('$nome', '$email', '$senha', '$telefone', '$celular', '$data_nasc', '$cpf', '$especialidade', '$estado', '$cidade')");
    } catch (Exception $e) {
         echo 'Falha no cadastro: ',  $e->getMessage(), "\n";
    }
                */
        

        $result= mysqli_query($conexao, "INSERT INTO tecnico(nome, email, senha, telefone, celular, data_nasc, cpf, especialidade, estado, cidade, tipo) VALUES ('$nome', '$email', '$senha', '$telefone', '$celular', '$data_nasc', '$cpf', '$especialidade', '$estado', '$cidade', '$tipo')");
        

    }
?>

<!DOCTYPE html> 
<html lang="pt-br">
  <head>
    <meta charset="UTF-8">
    <meta name="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!------------------------- LINKS ------------------------->

    <script src="https://kit.fontawesome.com/8c80796dd2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../estilos/menu_nav.css">
    <link rel="stylesheet" href="../estilos/cadastrar.css">
    <link rel="icon" href="ghost-solid.svg" type="image/png">
    <link rel="shortcut icon" href="../imagens/faviconMeAjudaAi.png" type="">
    <title>Cadastrar</title>
  </head>
<body>
<!-----------------------navbar------------------------------>
<nav>
        
  <a href="../index.html" id="pagina_inicial" ><span> <img src="../imagens/inicio.png" alt="Pagina Inicial" class="home"></span></a>

    <div id="amarelo"></div>

  <li><a href="../sobre.html" id="a">Sobre nós</a></li class="nav">

    <div id="amarelo"></div>

  <li ><a href="../como_funciona.html" id="a" >Como funciona? </a></li>

    <div id="amarelo"></div>
                          
    <div class="dropdown">
      <li><A class="dropbtn"  id="a"  >Problemas Comuns </A></li>
        <div class="dropdown-content">
          <a href="../tutorial.html">Como Trocar a resistência de chuveiro ?</a>
          <a href="../tutorial2.html">Como Trocar uma Lâmpada?</a>
          <a href="../tutorial3.html">Como Desentupir um Ralo?</a>
      </div>
    </div>

    <div id="amarelo"></div>

    <div class="dropdown" id="drop">
      <li><A class="dropbtn" id="a">Como Fazer? </A></li>
        <div class="dropdown-content">
          <a href="#">Como Fazer Arroz?</a>
          <a href="#">Como Fazer Um Bolo de Caneca?</a>
          <a href="#">Como Desentupir um Ralo?</a>
        </div>
    </div>

    <div id="amarelo" class="drop"></div>
      
    <div class="dropdown" id="drop">                    
      <li><A class="dropbtn" id="a">Algumas Dicas</A></li>
        <div class="dropdown-content">
          <a href="#">Como Fazer Arroz?</a>
          <a href="#">Como Fazer Um Bolo de Caneca?</a>
          <a href="#">Como Desentupir um Ralo?</a>
        </div>
    </div>
             
    <div id="amarelo" class="drop"></div>
        
  <li><a href="../feedback.html" id="a">Feedback's</a></li >

    <div id="amarelo"></div>

  <li id="login"><a href="../Login.html" >
    <div class="user">

      <img id="user-photo" src="../imagens/Design sem nome.png">
      <p id="user-email"></p></a></li>
    </div>   
</nav>
<!-----------------------navbar------------------------------>

    <div class="login-container">
      <form action="cadastro-tecnico.php" method="POST">
        <label>Nome Completo</label>
        <input type="text" name="nome" placeholder="Insira seu Nome Completo" required>

        <label>E-mail</label>
        <input type="email"  name="email" placeholder="Insira seu E-Mail" required>

        <label>Senha</label>
        <input type="password"  name="senha" placeholder="Insira sua senha" required>

        <label>Telefone</label>
        <input type="tel" id="fone" name="telefone" placeholder="Insira seu telefone (Opcional)">

        <label>Celular</label>
        <input type="tel" id="cel" name="celular" required pattern="[0-9]{2} [0-9]{9}" placeholder="(11) 99999-9999" required>

        <label>Data de nascimento</label>
        <input type="date" name="data_nasc" placeholder="Insira sua data de nascimento" required>

        <label>CPF</label>
        <input type="number" name="cpf" placeholder="Insira seu CPF" required>

        <label>Especialidade</label>
        <input type="text" name="especialidade" placeholder="Insira sua especialidade" required>

        <label>Região em que atua</label>

        <div class ="localidade">

          <select name="estado" id="estado">
            <option value="">SELECIONE</option>
          </select>

          <select name="cidade" id="cidade">
            <option value="">SELECIONE</option>
          </select>
        </div>

        <div class="sou-tecnico">
          <button type="submit" href="cadastro-tecnico.php" name="submit">enviar</button>
          <a  class="a-tecnico" href="cadastrar-usuario.php">Sou usuário</a>
        </div>

      </form>
    </div>

    <script src="../js/localidade.js"></script>
  </body>
</html>