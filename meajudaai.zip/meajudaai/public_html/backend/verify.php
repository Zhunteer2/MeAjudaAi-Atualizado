<?php 

    include_once('config.php');
    
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    
 $sql = "SELECT * FROM tecnico.email, tecnico.senha, usuarios.email, usuarios.senha FROM tecnico, usuarios WHERE (tecnico.email = '$email'  OR usuarios.email = '$email') AND (tecnico.senha = '$senha' OR usuarios.senha = '$senha')";

    if ($tipo = 'tipo == 1']
    {
        header('Location: ../index.html');
    } 
    else
    {
        header('Location: ../como_funciona.html');
    }
    

/*    $sql = "SELECT * FROM usuarios WHERE email = '$email' and senha = '$senha'";
    
    if (empty($sql))
    {
        header('Location: ../Login.html');
    } 
    else
    {
        echo "ISSO AI";    
    }
    
  */  
    
    
 //if (isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha']))

?>

