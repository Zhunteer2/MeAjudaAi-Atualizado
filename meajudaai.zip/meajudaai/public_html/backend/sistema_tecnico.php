<?php

    if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)){
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header('Location: ../Login.html');
    }
        $logado = $_SESSION['email'];
        header('Location: ../como_funciona.html');
        echo "<h1>Acesso ao sistema</h1>";
        echo $senha;

    session_start();
    print_r($_SESSION);
?>

<!DOCTYPE html> 
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!------------------------- LINKS ------------------------->

    <script src="https://kit.fontawesome.com/8c80796dd2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="estilos/menu_nav.css">
    <link rel="stylesheet" href="estilos/Login.css">
    <link rel="icon" href="ghost-solid.svg" type="image/png">
    <link rel="shortcut icon" href="./imagens/faviconMeAjudaAi.png" type="">
    <link rel="shortcut icon" href="./imagens/faviconMeAjudaAi.ico" type="">
    <link href="https://fonts.googleapis.com/css2?family=Archivo+Black&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Rowdies:wght@300;400;700&display=swap" rel="stylesheet">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google authentication - Exemplo 2</title>
    <link rel="stylesheet" href="css/style.css">  
    <!-- Fonte Roboto do Google -->
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" type="text/css">
    
    <title>Home</title>
</head>

<body>
  <!-----------------------navbar------------------------------>
<nav>
        
  <a href="index.html" id="pagina_inicial" ><span> <img src="imagens/inicio.png" alt="Pagina Inicial" class="home"></span></a>

    <div id="amarelo"></div>

  <li><a href="sobre.html" id="a">Sobre nós</a></li class="nav">

    <div id="amarelo"></div>

  <li ><a href="como_funciona.html" id="a" >Como funciona? </a></li>

    <div id="amarelo"></div>
                          
    <div class="dropdown"  >
      <li><A class="dropbtn"  id="a"  >Problemas Comuns </A></li>
        <div class="dropdown-content">
          <a href="tutorial.html">Como Trocar a resistência de chuveiro ?</a>
          <a href="tutorial2.html">Como Trocar uma Lâmpada?</a>
          <a href="tutorial3.html">Como Desentupir um Ralo?</a>
      </div>
    </div>

    <div id="amarelo"  ></div>

    <div class="dropdown" id="drop">
      <li><A class="dropbtn" id="a">Como Fazer? </A></li>
        <div class="dropdown-content">
          <a href="#">Como Fazer Arroz?</a>
          <a href="#">Como Fazer Um Bolo de Caneca?</a>
          <a href="#">Como Desentupir um Ralo?</a>
        </div>
    </div>

    <div id="amarelo" class="drop"></div>
      
    <div class="dropdown" id="drop">                    
      <li><A class="dropbtn" id="a">Algumas Dicas</A></li>
        <div class="dropdown-content">
          <a href="#">Como Fazer Arroz?</a>
          <a href="#">Como Fazer Um Bolo de Caneca?</a>
          <a href="#">Como Desentupir um Ralo?</a>
        </div>
    </div>
             
    <div id="amarelo" class="drop"></div>
        
  <li><a href="feedback.html" id="a">Feedback's</a></li >

    <div id="amarelo"></div>

  <li id="login"><a href="Login.html" >
    <div class="user">

      <img id="user-photo" src="imagens/Design sem nome.png">
      <p id="user-email"></p></a></li>
    </div>   
</nav>

<!------------------------------------------------------------>

<a href="" class="sair"> Sair</a>


<style>
    .sair{
        background-color: red;
        color: white;
        font-size: 18px;
        padding:6px;
    }
</style>

</body>
</html>