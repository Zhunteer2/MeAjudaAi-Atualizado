<?php
    $dbhost = "Localhost";
    $dbUsername = "id21516821_meajudaaitcc";
    $dbPassword = "@Admin123";
    $dbname = "id21516821_meajudaaitcc";
    

    $conexao = new mysqli($dbhost, $dbUsername, $dbPassword, $dbname);


    /*
    if ($conexao -> connect_errno)
    {
        echo "Erro";
    } 
    else {
        echo "Conexão efetuada com sucesso";
    }
    */

?>